import React, { useState, useEffect } from 'react';
import { 
  X, 
  Upload, 
  Plus, 
  Trash2, 
  Globe, 
  Save, 
  Image as ImageIcon, 
  Palette, 
  Check,
  ChevronDown,
  ChevronUp,
  Package
} from 'lucide-react';
import { Product, ProductVariant, Category } from '../types';
import { storage, sanitizeForFirestore } from '../firebase';
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import { cn } from '../lib/utils';
import ImageCropper from './ImageCropper';
import { CATEGORIES_CONFIG, BRANDS, PLACEHOLDER_IMAGE } from '../constants';

interface ProductFormProps {
  product?: Product | null;
  categories: Category[];
  onSubmit: (productData: Partial<Product>) => Promise<void>;
  onClose: () => void;
}

const PREDEFINED_COLORS = [
  { name: 'أسود', hex: '#000000' },
  { name: 'أبيض', hex: '#FFFFFF' },
  { name: 'أحمر', hex: '#FF0000' },
  { name: 'أزرق', hex: '#0000FF' },
  { name: 'أخضر', hex: '#008000' },
  { name: 'رمادي', hex: '#808080' },
  { name: 'بني', hex: '#A52A2A' },
  { name: 'ذهبي', hex: '#FFD700' },
];

export default function ProductForm({ product, categories, onSubmit, onClose }: ProductFormProps) {
  const [formData, setFormData] = useState<Partial<Product>>(() => {
    const base: Partial<Product> = {
      name: '',
      description: '',
      price: 0,
      category: '',
      subCategory: '',
      brand: '',
      imageUrl: '',
      imageUrls: [],
      stock: 0,
      stockStatus: 'in-stock',
      rating: 5,
      sizes: [],
      colors: [],
      variants: [],
      metaTitle: '',
      metaDescription: '',
      badge: 'none'
    };
    return product ? { ...base, ...product } : base;
  });

  const [uploading, setUploading] = useState(false);
  const [croppingImage, setCroppingImage] = useState<string | null>(null);
  const [customColor, setCustomColor] = useState('#000000');
  const [showVariantForm, setShowVariantForm] = useState(false);
  const [imageMode, setImageMode] = useState<'upload' | 'url'>('upload');
  const [newImageUrl, setNewImageUrl] = useState('');
  const [newVariant, setNewVariant] = useState({
    size: '',
    color: '',
    colorHex: '',
    stock: '' as string | number,
    price: '' as string | number
  });

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || !files[0]) return;

    const file = files[0];
    const reader = new FileReader();
    reader.onload = () => {
      setCroppingImage(reader.result as string);
    };
    reader.readAsDataURL(file);
    // Reset input
    e.target.value = '';
  };

  const onCropComplete = async (croppedBlob: Blob) => {
    setCroppingImage(null);
    setUploading(true);
    
    const fileName = `products/${Date.now()}-cropped.jpg`;
    const storageRef = ref(storage, fileName);
    
    try {
      const snapshot = await uploadBytes(storageRef, croppedBlob);
      const url = await getDownloadURL(snapshot.ref);
      
      const newUrls = [...(formData.imageUrls || []), url];
      setFormData(prev => ({ 
        ...prev, 
        imageUrls: newUrls,
        imageUrl: prev.imageUrl || url 
      }));
      toast.success('تم رفع الصورة بنجاح');
    } catch (error) {
      toast.error('فشل رفع الصورة');
    } finally {
      setUploading(false);
    }
  };

  const addImageUrl = () => {
    if (!newImageUrl.trim()) return;
    if (!newImageUrl.startsWith('http')) {
      toast.error('يرجى إدخال رابط صحيح يبدأ بـ http');
      return;
    }

    const newUrls = [...(formData.imageUrls || []), newImageUrl.trim()];
    setFormData(prev => ({
      ...prev,
      imageUrls: newUrls,
      imageUrl: prev.imageUrl || newImageUrl.trim()
    }));
    setNewImageUrl('');
    toast.success('تم إضافة الرابط بنجاح');
  };

  const removeImage = async (url: string) => {
    const newUrls = (formData.imageUrls || []).filter(u => u !== url);
    setFormData(prev => ({ 
      ...prev, 
      imageUrls: newUrls,
      imageUrl: prev.imageUrl === url ? (newUrls[0] || '') : prev.imageUrl
    }));
    // Note: We could delete from storage too, but let's keep it simple for now
  };

  const addVariant = () => {
    if (newVariant.stock === '') return;
    
    const variant: ProductVariant = {
      id: Math.random().toString(36).substr(2, 9),
      size: newVariant.size || '',
      color: newVariant.color || '',
      colorHex: newVariant.colorHex || '',
      stock: Number(newVariant.stock),
      price: newVariant.price !== '' ? Number(newVariant.price) : undefined
    };

    setFormData(prev => ({
      ...prev,
      variants: [...(prev.variants || []), variant]
    }));

    setNewVariant({ size: '', color: '', colorHex: '', stock: '', price: '' });
  };

  const removeVariant = (id: string) => {
    setFormData(prev => ({
      ...prev,
      variants: (prev.variants || []).filter(v => v.id !== id)
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Ensure all fields are present and no undefined values
    const sanitizedData = sanitizeForFirestore(formData);
    await onSubmit(sanitizedData);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="relative bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        <div className="bg-brand-blue text-white p-6 flex justify-between items-center shrink-0">
          <h3 className="text-xl font-bold">{product ? 'تعديل المنتج' : 'إضافة منتج جديد'}</h3>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-8 overflow-y-auto space-y-8">
          {/* Basic Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="block text-sm font-bold text-gray-700">اسم المنتج</label>
              <input 
                required
                type="text" 
                className="w-full bg-gray-50 border border-gray-200 rounded-lg py-2 px-4 outline-none focus:ring-2 focus:ring-brand-blue"
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-bold text-gray-700">الفئة الرئيسية</label>
              <select 
                required
                className="w-full bg-gray-50 border border-gray-200 rounded-lg py-2 px-4 outline-none focus:ring-2 focus:ring-brand-blue"
                value={formData.category}
                onChange={e => {
                  const newCat = e.target.value;
                  const config = CATEGORIES_CONFIG.find(c => c.name === newCat);
                  setFormData({
                    ...formData, 
                    category: newCat,
                    subCategory: config?.subcategories[0] || ''
                  });
                }}
              >
                <option value="">اختر الفئة</option>
                {CATEGORIES_CONFIG.map(cat => (
                  <option key={cat.id} value={cat.name}>{cat.name}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-bold text-gray-700">الفئة الفرعية</label>
              <select 
                className="w-full bg-gray-50 border border-gray-200 rounded-lg py-2 px-4 outline-none focus:ring-2 focus:ring-brand-blue"
                value={formData.subCategory}
                onChange={e => setFormData({...formData, subCategory: e.target.value})}
                disabled={!formData.category}
              >
                <option value="">اختر الفئة الفرعية</option>
                {CATEGORIES_CONFIG.find(c => c.name === formData.category)?.subcategories.map(sub => (
                  <option key={sub} value={sub}>{sub}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-bold text-gray-700">الماركة / العلامة التجارية</label>
              <div className="relative">
                <input 
                  type="text" 
                  list="brands-list"
                  placeholder="اختر أو اكتب الماركة"
                  className="w-full bg-gray-50 border border-gray-200 rounded-lg py-2 px-4 outline-none focus:ring-2 focus:ring-brand-blue"
                  value={formData.brand || ''}
                  onChange={e => setFormData({...formData, brand: e.target.value})}
                />
                <datalist id="brands-list">
                  {BRANDS.map(brand => (
                    <option key={brand} value={brand} />
                  ))}
                </datalist>
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-bold text-gray-700">السعر الأساسي (SDG)</label>
              <input 
                required
                type="number" 
                className="w-full bg-gray-50 border border-gray-200 rounded-lg py-2 px-4 outline-none focus:ring-2 focus:ring-brand-blue"
                value={formData.price}
                onChange={e => setFormData({...formData, price: Number(e.target.value)})}
              />
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-bold text-gray-700">حالة المخزون</label>
              <div className="flex items-center gap-4 h-10">
                <button
                  type="button"
                  onClick={() => setFormData({...formData, stockStatus: 'in-stock'})}
                  className={cn(
                    "flex-1 py-2 rounded-lg text-xs font-bold transition-all",
                    formData.stockStatus === 'in-stock' ? "bg-green-100 text-green-700 border border-green-200" : "bg-gray-50 text-gray-400 border border-transparent"
                  )}
                >
                  متوفر
                </button>
                <button
                  type="button"
                  onClick={() => setFormData({...formData, stockStatus: 'out-of-stock'})}
                  className={cn(
                    "flex-1 py-2 rounded-lg text-xs font-bold transition-all",
                    formData.stockStatus === 'out-of-stock' ? "bg-red-100 text-red-700 border border-red-200" : "bg-gray-50 text-gray-400 border border-transparent"
                  )}
                >
                  نفذ من المخزون
                </button>
              </div>
            </div>
          </div>

          {/* Image Upload & URL */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="block text-sm font-bold text-gray-700">صور المنتج (غير محدود)</label>
              <div className="flex bg-gray-100 p-1 rounded-lg">
                <button
                  type="button"
                  onClick={() => setImageMode('upload')}
                  className={cn(
                    "px-3 py-1 text-[10px] font-bold rounded-md transition-all",
                    imageMode === 'upload' ? "bg-white text-brand-blue shadow-sm" : "text-gray-500"
                  )}
                >
                  رفع ملف
                </button>
                <button
                  type="button"
                  onClick={() => setImageMode('url')}
                  className={cn(
                    "px-3 py-1 text-[10px] font-bold rounded-md transition-all",
                    imageMode === 'url' ? "bg-white text-brand-blue shadow-sm" : "text-gray-500"
                  )}
                >
                  رابط صورة
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-4">
              {formData.imageUrls?.map((url, idx) => (
                <div key={idx} className="relative aspect-square rounded-xl overflow-hidden border group">
                  <img src={url || PLACEHOLDER_IMAGE} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  <button 
                    type="button"
                    onClick={() => removeImage(url)}
                    className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Trash2 size={14} />
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({...formData, imageUrl: url})}
                    className={cn(
                      "absolute bottom-0 inset-x-0 py-0.5 text-[8px] text-center font-bold transition-all",
                      formData.imageUrl === url ? "bg-brand-blue text-white" : "bg-black/50 text-white opacity-0 group-hover:opacity-100"
                    )}
                  >
                    {formData.imageUrl === url ? 'الصورة الرئيسية' : 'تعيين كرئيسية'}
                  </button>
                </div>
              ))}

              {imageMode === 'upload' ? (
                <label className="aspect-square rounded-xl border-2 border-dashed border-gray-200 flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-gray-50 transition-colors">
                  <Upload className={cn("text-gray-400", uploading && "animate-bounce")} />
                  <span className="text-[10px] text-gray-400 font-bold">{uploading ? 'جاري الرفع...' : 'رفع صور'}</span>
                  <input type="file" multiple accept="image/*" className="hidden" onChange={handleImageUpload} disabled={uploading} />
                </label>
              ) : (
                <div className="col-span-2 sm:col-span-3 aspect-square sm:aspect-auto sm:h-full rounded-xl border-2 border-dashed border-gray-200 p-4 flex flex-col justify-center gap-2">
                  <div className="flex gap-2">
                    <input 
                      type="text"
                      placeholder="أدخل رابط الصورة (URL)"
                      className="flex-1 bg-white border border-gray-200 rounded-lg py-1.5 px-3 text-xs outline-none focus:ring-1 focus:ring-brand-blue"
                      value={newImageUrl}
                      onChange={e => setNewImageUrl(e.target.value)}
                    />
                    <button
                      type="button"
                      onClick={addImageUrl}
                      className="bg-brand-blue text-white px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-brand-blue/90"
                    >
                      إضافة
                    </button>
                  </div>
                  <p className="text-[8px] text-gray-400">يمكنك استخدام روابط من مواقع مثل ImgBB أو غيرها.</p>
                </div>
              )}
            </div>
          </div>

          {/* Color Selector */}
          <div className="space-y-4">
            <label className="block text-sm font-bold text-gray-700">الألوان المتاحة</label>
            <div className="flex flex-wrap gap-3">
              {PREDEFINED_COLORS.map(color => (
                <button
                  key={color.hex}
                  type="button"
                  onClick={() => {
                    const colors = formData.colors || [];
                    if (colors.includes(color.name)) {
                      setFormData({ ...formData, colors: colors.filter(c => c !== color.name) });
                    } else {
                      setFormData({ ...formData, colors: [...colors, color.name] });
                    }
                  }}
                  className={cn(
                    "flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs font-bold transition-all",
                    formData.colors?.includes(color.name) ? "border-brand-blue bg-brand-blue/5 text-brand-blue" : "border-gray-200 hover:border-gray-300"
                  )}
                >
                  <div className="w-3 h-3 rounded-full border border-gray-200" style={{ backgroundColor: color.hex }} />
                  {color.name}
                  {formData.colors?.includes(color.name) && <Check size={12} />}
                </button>
              ))}
              <div className="flex items-center gap-2">
                <input 
                  type="color" 
                  value={customColor}
                  onChange={e => setCustomColor(e.target.value)}
                  className="w-8 h-8 rounded-lg cursor-pointer border-none p-0"
                />
                <button
                  type="button"
                  onClick={() => {
                    const colors = formData.colors || [];
                    if (!colors.includes(customColor)) {
                      setFormData({ ...formData, colors: [...colors, customColor] });
                    }
                  }}
                  className="text-xs font-bold text-brand-blue hover:underline"
                >
                  إضافة لون مخصص
                </button>
              </div>
            </div>
          </div>

          {/* Variants Section */}
          <div className="space-y-4 border-t pt-6">
            <div className="flex justify-between items-center">
              <h4 className="font-bold flex items-center gap-2"><Package size={18} /> تتبع المخزون (الأنواع)</h4>
              <button 
                type="button"
                onClick={() => setShowVariantForm(!showVariantForm)}
                className="text-brand-blue text-sm font-bold flex items-center gap-1"
              >
                {showVariantForm ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                {showVariantForm ? 'إغلاق' : 'إضافة نوع جديد'}
              </button>
            </div>

            {showVariantForm && (
              <div className="bg-gray-50 p-6 rounded-2xl border border-gray-200 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-6 gap-4 items-end">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500">المقاس</label>
                  <input 
                    type="text" 
                    placeholder="مثال: XL"
                    className="w-full bg-white border border-gray-200 rounded-lg py-1.5 px-3 text-sm outline-none focus:ring-1 focus:ring-brand-blue"
                    value={newVariant.size}
                    onChange={e => setNewVariant({...newVariant, size: e.target.value})}
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500">اللون</label>
                  <input 
                    type="text" 
                    placeholder="مثال: أحمر"
                    className="w-full bg-white border border-gray-200 rounded-lg py-1.5 px-3 text-sm outline-none focus:ring-1 focus:ring-brand-blue"
                    value={newVariant.color}
                    onChange={e => setNewVariant({...newVariant, color: e.target.value})}
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500">كود اللون</label>
                  <div className="flex gap-2">
                    <input 
                      type="color" 
                      className="w-10 h-8 rounded cursor-pointer border-none p-0"
                      value={newVariant.colorHex || '#000000'}
                      onChange={e => setNewVariant({...newVariant, colorHex: e.target.value})}
                    />
                    <input 
                      type="text" 
                      placeholder="#000000"
                      className="w-full bg-white border border-gray-200 rounded-lg py-1.5 px-2 text-[10px] outline-none focus:ring-1 focus:ring-brand-blue"
                      value={newVariant.colorHex || ''}
                      onChange={e => setNewVariant({...newVariant, colorHex: e.target.value})}
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500">الكمية</label>
                  <input 
                    type="number" 
                    className="w-full bg-white border border-gray-200 rounded-lg py-1.5 px-3 text-sm outline-none focus:ring-1 focus:ring-brand-blue"
                    value={newVariant.stock}
                    onChange={e => setNewVariant({...newVariant, stock: e.target.value === '' ? '' as any : Number(e.target.value)})}
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500">السعر (اختياري)</label>
                  <input 
                    type="number" 
                    placeholder="تجاوز السعر"
                    className="w-full bg-white border border-gray-200 rounded-lg py-1.5 px-3 text-sm outline-none focus:ring-1 focus:ring-brand-blue"
                    value={newVariant.price}
                    onChange={e => setNewVariant({...newVariant, price: e.target.value === '' ? '' as any : Number(e.target.value)})}
                  />
                </div>
                <button 
                  type="button"
                  onClick={addVariant}
                  className="bg-brand-blue text-white py-2 rounded-lg text-sm font-bold hover:bg-brand-blue/90"
                >
                  إضافة النوع
                </button>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {formData.variants?.map(variant => (
                <div key={variant.id} className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex justify-between items-center group">
                  <div className="flex items-center gap-3">
                    {variant.colorHex && (
                      <div className="w-4 h-4 rounded-full border border-gray-200" style={{ backgroundColor: variant.colorHex }} />
                    )}
                    <div>
                      <p className="text-sm font-bold">{variant.size} {variant.color && `- ${variant.color}`}</p>
                      <p className="text-xs text-gray-500">المخزون: {variant.stock} | {variant.price ? `${variant.price} SDG` : 'السعر الأساسي'}</p>
                      {variant.stock < 3 && <span className="text-[8px] text-red-500 font-bold">مخزون منخفض!</span>}
                    </div>
                  </div>
                  <button 
                    type="button"
                    onClick={() => removeVariant(variant.id)}
                    className="text-red-400 hover:text-red-600 p-2 transition-colors"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* SEO Section */}
          <div className="space-y-4 border-t pt-6">
            <h4 className="font-bold flex items-center gap-2"><Globe size={18} /> إعدادات SEO</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="block text-sm font-bold text-gray-700">عنوان Meta</label>
                <input 
                  type="text" 
                  className="w-full bg-gray-50 border border-gray-200 rounded-lg py-2 px-4 outline-none focus:ring-2 focus:ring-brand-blue"
                  value={formData.metaTitle}
                  onChange={e => setFormData({...formData, metaTitle: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <label className="block text-sm font-bold text-gray-700">وصف Meta</label>
                <input 
                  type="text" 
                  className="w-full bg-gray-50 border border-gray-200 rounded-lg py-2 px-4 outline-none focus:ring-2 focus:ring-brand-blue"
                  value={formData.metaDescription}
                  onChange={e => setFormData({...formData, metaDescription: e.target.value})}
                />
              </div>
            </div>
          </div>

          <div className="pt-6 border-t">
            <button type="submit" className="w-full btn-primary py-4 flex items-center justify-center gap-2 text-lg">
              <Save size={24} />
              {product ? 'حفظ التعديلات' : 'إضافة المنتج للمتجر'}
            </button>
          </div>
        </form>

        <AnimatePresence>
          {croppingImage && (
            <ImageCropper 
              image={croppingImage}
              onCropComplete={onCropComplete}
              onCancel={() => setCroppingImage(null)}
            />
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
