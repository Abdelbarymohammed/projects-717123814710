import React, { useState } from 'react';
import { Lock, Mail, ArrowRight, ShieldCheck, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { auth, login, handleFirestoreError, OperationType } from '../firebase';
import { toast } from 'sonner';

interface AdminLoginProps {
  onLoginSuccess: () => void;
  onBack: () => void;
}

export default function AdminLogin({ onLoginSuccess, onBack }: AdminLoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Requirement: Authorized admin email is Abdowm36@gmail.com
    if (email.toLowerCase() !== 'abdowm36@gmail.com') {
      toast.error('هذا البريد الإلكتروني غير مصرح له بالدخول كمسؤول');
      return;
    }

    setIsLoading(true);
    try {
      await login(email, password);
      toast.success('تم تسجيل الدخول بنجاح');
      onLoginSuccess();
    } catch (error: any) {
      console.error("Admin login error:", error);
      if (error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
        toast.error('كلمة المرور غير صحيحة');
      } else if (error.code === 'auth/user-not-found') {
        toast.error('المستخدم غير موجود');
      } else {
        toast.error('حدث خطأ أثناء تسجيل الدخول');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-brand-blue flex items-center justify-center p-4" dir="rtl">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white p-8 rounded-2xl shadow-2xl max-w-md w-full text-center"
      >
        <div className="bg-brand-gray w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 text-brand-blue">
          <ShieldCheck size={40} />
        </div>
        <h2 className="text-2xl font-bold mb-2">دخول المسؤول</h2>
        <p className="text-gray-500 mb-8 text-sm">يرجى إدخال بيانات الاعتماد للوصول إلى لوحة التحكم</p>
        
        <form onSubmit={handleLogin} className="space-y-4">
          <div className="relative">
            <Mail className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input 
              type="email" 
              placeholder="البريد الإلكتروني"
              className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 pr-12 pl-4 outline-none focus:ring-2 focus:ring-brand-blue transition-all"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
            />
          </div>
          
          <div className="relative">
            <Lock className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input 
              type="password" 
              placeholder="كلمة المرور"
              className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 pr-12 pl-4 outline-none focus:ring-2 focus:ring-brand-blue transition-all"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
            />
          </div>

          <button 
            type="submit" 
            disabled={isLoading}
            className="w-full btn-primary py-3 rounded-xl flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <Loader2 className="animate-spin" size={20} />
            ) : (
              <>
                <span>تسجيل الدخول</span>
                <ArrowRight size={20} />
              </>
            )}
          </button>
          
          <button 
            type="button"
            onClick={onBack}
            className="w-full text-gray-400 text-sm hover:text-brand-blue transition-colors mt-4"
          >
            العودة للمتجر
          </button>
        </form>
      </motion.div>
    </div>
  );
}
