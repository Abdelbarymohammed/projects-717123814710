import { Product, SiteConfig } from './types';

export const PLACEHOLDER_IMAGE = 'https://images.unsplash.com/photo-1560393464-5c69a73c5770?q=80&w=600&h=800&auto=format&fit=crop';

export const SAMPLE_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'فستان صيفي أنيق',
    description: 'فستان صيفي خفيف ومريح بتصميم عصري وأنيق، مثالي للمناسبات الصباحية والخرجات الصيفية. مصنوع من أجود أنواع القطن السوداني.',
    price: 45000,
    category: 'أزياء',
    imageUrl: 'https://picsum.photos/seed/dress1/600/800',
    stock: 10,
    stockStatus: 'in-stock',
    rating: 4.5,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['White', 'Pink', 'Blue'],
    reviews: [
      { id: 'r1', productId: '1', userId: '1', userName: 'سارة أحمد', rating: 5, comment: 'خامة ممتازة وتصميم رائع جداً!', date: '2024-03-20', status: 'approved', likes: 0, likedBy: [] },
      { id: 'r2', productId: '1', userId: '2', userName: 'منى علي', rating: 4, comment: 'جميل جداً ومريح في اللبس.', date: '2024-03-18', status: 'approved', likes: 0, likedBy: [] }
    ]
  },
  {
    id: '2',
    name: 'قميص رجالي كاجوال',
    description: 'قميص قطني مريح مناسب لجميع الأوقات، يتميز بقصة عصرية وألوان جذابة تناسب الذوق الرفيع.',
    price: 25000,
    category: 'أزياء',
    imageUrl: 'https://picsum.photos/seed/shirt1/600/800',
    stock: 15,
    stockStatus: 'in-stock',
    rating: 4.2,
    sizes: ['M', 'L', 'XL', 'XXL'],
    colors: ['Blue', 'Grey', 'Black'],
    reviews: [
      { id: 'r3', productId: '2', userId: '3', userName: 'محمد عثمان', rating: 4, comment: 'جيد جداً وسعره مناسب.', date: '2024-03-15', status: 'approved', likes: 0, likedBy: [] }
    ]
  },
  {
    id: '3',
    name: 'حقيبة يد جلدية',
    description: 'حقيبة يد فاخرة مصنوعة من الجلد الطبيعي، تصميم كلاسيكي يضيف لمسة من الرقي لإطلالتك.',
    price: 65000,
    category: 'أزياء',
    imageUrl: 'https://picsum.photos/seed/bag1/600/800',
    stock: 5,
    stockStatus: 'in-stock',
    rating: 4.8,
    colors: ['Brown', 'Black', 'Tan'],
    reviews: [
      { id: 'r4', productId: '3', userId: '4', userName: 'فاطمة حسن', rating: 5, comment: 'الجلد طبيعي وواضح جداً الجودة العالية.', date: '2024-03-22', status: 'approved', likes: 0, likedBy: [] }
    ]
  },
  {
    id: '4',
    name: 'حذاء رياضي عصري',
    description: 'حذاء رياضي مريح وخفيف الوزن، مثالي للمشي والجري والاستخدام اليومي الشاق.',
    price: 35000,
    category: 'أزياء',
    imageUrl: 'https://picsum.photos/seed/shoes1/600/800',
    stock: 8,
    stockStatus: 'in-stock',
    rating: 4.6,
    sizes: ['40', '41', '42', '43', '44'],
    colors: ['White', 'Black', 'Grey']
  },
  {
    id: '5',
    name: 'هاتف ذكي حديث',
    description: 'هاتف ذكي بأحدث المواصفات، كاميرا عالية الدقة وبطارية تدوم طويلاً.',
    price: 250000,
    category: 'إلكترونيات',
    imageUrl: 'https://picsum.photos/seed/phone1/600/800',
    stock: 5,
    stockStatus: 'in-stock',
    rating: 4.9,
    colors: ['Black', 'Silver', 'Gold']
  },
  {
    id: '6',
    name: 'طقم أواني منزلية',
    description: 'طقم أواني طهي متكامل، جودة عالية وتصميم عصري لمطبخك.',
    price: 85000,
    category: 'منزل وديكور',
    imageUrl: 'https://picsum.photos/seed/home1/600/800',
    stock: 12,
    stockStatus: 'in-stock',
    rating: 4.4,
    colors: ['Silver', 'Red']
  },
  {
    id: '7',
    name: 'مجموعة العناية بالبشرة',
    description: 'مجموعة متكاملة للعناية بالبشرة بمكونات طبيعية لجمال يدوم.',
    price: 45000,
    category: 'جمال وعناية',
    imageUrl: 'https://picsum.photos/seed/beauty1/600/800',
    stock: 20,
    stockStatus: 'in-stock',
    rating: 4.7,
    colors: ['Natural']
  }
];

export const CATEGORIES_CONFIG = [
  {
    id: 'men-fashion',
    name: 'أزياء رجالية',
    subcategories: ['تيشرتات', 'بناطيل', 'ساعات', 'جاكيتات', 'جلابيات', 'ملابس داخلية', 'ملابس رياضية', 'قمصان', 'حقائب']
  },
  {
    id: 'women-fashion',
    name: 'أزياء نسائية',
    subcategories: ['فساتين', 'عبايات', 'بلايز', 'بناطيل', 'حقائب يد', 'مجوهرات', 'أحذية', 'لانجري']
  },
  {
    id: 'electronics',
    name: 'إلكترونيات',
    subcategories: ['ساعات ذكية', 'أجهزة منزلية', 'هواتف ذكية', 'لابتوبات', 'إكسسوارات']
  },
  {
    id: 'beauty-care',
    name: 'جمال وعناية',
    subcategories: ['كريمات', 'عطور', 'مرطبات', 'مكياج', 'عناية بالشعر']
  },
  {
    id: 'accessories',
    name: 'إكسسوارات',
    subcategories: ['نظارات شمسية', 'محافظ', 'أحزمة', 'مجوهرات']
  }
];

export const BRANDS = [
  'Apple', 'Samsung', 'Huawei', 'Xiaomi', 'Oppo', 'Vivo', 'Realme',
  'Nike', 'Adidas', 'Puma', 'Reebok', 'Under Armour',
  'Zara', 'H&M', 'Mango', 'Gucci', 'Prada', 'Dior', 'Chanel', 'Louis Vuitton',
  'L\'Oreal', 'Nivea', 'Dove', 'Maybelline', 'MAC'
];

export const DEFAULT_SITE_CONFIG: SiteConfig = {
  primaryColor: '#003366',
  secondaryColor: '#FFFFFF',
  fontFamily: 'Cairo',
  mobileGridColumns: 2,
  announcementBar: {
    text: 'توصيل مجاني للطلبات فوق 50 ألف جنيه',
    enabled: true,
    backgroundColor: '#003366',
    textColor: '#FFFFFF'
  },
  shippingPrices: {
    khartoum: 5000,
    omdurman: 7000,
    bahri: 6000,
    states: 15000
  },
  shippingRates: [
    { id: '1', region: 'الخرطوم (المدينة)', price: 10000 },
    { id: '2', region: 'أم درمان', price: 7000 },
    { id: '3', region: 'الخرطوم بحري', price: 10000 },
    { id: '4', region: 'الولايات الأخرى', price: 15000 }
  ]
};
